BOMB GAME
1. This file will be running in administrator
2. Do not try and do anything funny with this
Password: Bomb